import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-corona',
  templateUrl: './corona.component.html',
  styleUrls: ['./corona.component.css']
})
export class CoronaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
