export class Login
{
    constructor(
        public email='',
        public password=''){}
}